const { escapeHtml } = require('../utils/helpers');

function clientScript() {
  return `
const video = document.getElementById('video-player');
const titleEl = document.getElementById('now-playing-title');
const statusEl = document.getElementById('now-playing-status');
const programEl = document.getElementById('now-playing-program');

let shakaPlayer;
let pendingStream;

function escapeHtmlText(value) {
  const amp = String.fromCharCode(38);

  return String(value || '')
    .replace(/&/g, amp + 'amp;')
    .replace(/</g, amp + 'lt;')
    .replace(/>/g, amp + 'gt;')
    .replace(/"/g, amp + 'quot;')
    .replace(/'/g, amp + '#039;');
}

function updateProgram(name, isJioSource) {
  const safeName = escapeHtmlText(name);

  if (!safeName) {
    programEl.innerHTML = '';
    return;
  }

  const videoIcon =
    '<img src="/video.svg" alt="Now Playing" width="25" height="25"> ';
  const jioBadge = isJioSource
    ? ' <img src="/jio-logo.svg" alt="JioTV EPG" width="14" height="14" class="jio-epg-badge">'
    : '';

  programEl.innerHTML = videoIcon + safeName + jioBadge;
}

async function loadStream(url, streamCandidates = []) {
  if (!shakaPlayer) {
    pendingStream = {
      url,
      streamCandidates
    };
    return;
  }

  try {
    statusEl.textContent = 'Connecting...';
    statusEl.className = 'text-info';

    await shakaPlayer.load(url);

    statusEl.textContent = 'Live';
    statusEl.className = 'text-success live-status';
  } catch (error) {
    console.error(error);

    const candidates = Array.isArray(streamCandidates) && streamCandidates.length
      ? streamCandidates
      : [url];

    const currentIndex = candidates.indexOf(url);

    if (currentIndex >= 0 && currentIndex < candidates.length - 1) {
      statusEl.textContent = 'Trying alternate stream...';
      statusEl.className = 'text-warning';
      return loadStream(candidates[currentIndex + 1], candidates);
    }

    statusEl.textContent = 'Stream unavailable';
    statusEl.className = 'text-danger';
  }
}

async function init() {
  const ui = video.ui;

  if (!ui) {
    statusEl.textContent = 'Player unavailable';
    return;
  }

  shakaPlayer = ui.getControls().getPlayer();

  shakaPlayer.addEventListener('error', () => {
    statusEl.textContent = 'Stream unavailable';
    statusEl.className = 'text-danger';
  });

  if (pendingStream) {
    const stream = pendingStream;
    pendingStream = null;
    loadStream(stream.url, stream.streamCandidates || [stream.url]);
  }
}

document.addEventListener('shaka-ui-loaded', init);

const clockEl = document.getElementById('server-clock');

if (clockEl) {
  const serverEpoch = Number(clockEl.getAttribute('data-server-epoch') || Date.now());
  const startTime = Date.now();

  function renderClock() {
    const serverNow = new Date(serverEpoch + (Date.now() - startTime));

    clockEl.textContent = serverNow.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23'
    });
  }

  renderClock();
  setInterval(renderClock, 1000);
}

const countryPicker = document.getElementById('country-picker-toggle');
const countryMenu = document.getElementById('country-picker-menu');

function getFlagUrl(code) {
  const normalizedCode = String(code || '').trim().toUpperCase();
  const flagCode = normalizedCode === 'UK' ? 'GB' : normalizedCode;
  return 'https://flagcdn.com/20x15/' + flagCode.toLowerCase() + '.png';
}

if (countryPicker && countryMenu) {
  countryPicker.addEventListener('click', () => {
    countryMenu.hidden = !countryMenu.hidden;
  });

  countryMenu.addEventListener('click', (event) => {
    const option = event.target.closest('.country-option');

    if (!option) {
      return;
    }

    const code = option.dataset.country;
    const form = countryPicker.closest('form');
    const hidden = form.querySelector('[name="country"]');

    hidden.value = code;

    countryPicker.querySelector('span').innerHTML = code
      ? '<img src="' + getFlagUrl(code) + '" alt="Country flag" width="20" height="15"> ' + option.textContent.trim()
      : '🌎 All countries';

    countryMenu.hidden = true;
  });

  document.addEventListener('click', (event) => {
    if (!countryPicker.contains(event.target) && !countryMenu.contains(event.target)) {
      countryMenu.hidden = true;
    }
  });
}

const categoryPicker = document.getElementById('category-picker-toggle');
const categoryMenu = document.getElementById('category-picker-menu');

if (categoryPicker && categoryMenu) {
  categoryPicker.addEventListener('click', () => {
    categoryMenu.hidden = !categoryMenu.hidden;
  });

  categoryMenu.addEventListener('click', (event) => {
    const option = event.target.closest('.country-option');

    if (!option) {
      return;
    }

    const categoryId = option.dataset.category || '';
    const form = categoryPicker.closest('form');
    const hidden = form.querySelector('[name="category"]');

    hidden.value = categoryId;

    categoryPicker.querySelector('span').innerHTML = categoryId
      ? option.innerHTML
      : '📺 All categories';

    categoryMenu.hidden = true;
  });

  document.addEventListener('click', (event) => {
    if (!categoryPicker.contains(event.target) && !categoryMenu.contains(event.target)) {
      categoryMenu.hidden = true;
    }
  });
}

async function loadPage(url, updateHistory = true) {
  const channelList = document.getElementById('channel-list');
  const pagination = document.getElementById('pagination-container');

  channelList.setAttribute('aria-busy', 'true');

  try {
    const response = await fetch(url, {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    });

    if (!response.ok) {
      throw new Error('Page request failed');
    }

    const documentFragment = new DOMParser().parseFromString(await response.text(), 'text/html');

    const nextList = documentFragment.getElementById('channel-list');
    const nextPagination = documentFragment.getElementById('pagination-container');
    const nextChannelCount = documentFragment.querySelector('.channel-count');
    const nextResultCount = documentFragment.querySelector('.result-count');
    const nextSectionTitle = documentFragment.querySelector('.section-heading h2');

    const currentChannelCount = document.querySelector('.channel-count');
    const currentResultCount = document.querySelector('.result-count');
    const currentSectionTitle = document.querySelector('.section-heading h2');

    const currentClearButton = document.querySelector('#filter-form .clear-button');
    const nextClearButton = documentFragment.querySelector('#filter-form .clear-button');

    if (!nextList || !nextPagination) {
      throw new Error('Missing page content');
    }

    channelList.innerHTML = nextList.innerHTML;
    pagination.replaceWith(nextPagination);

    if (nextChannelCount && currentChannelCount) {
      currentChannelCount.innerHTML = nextChannelCount.innerHTML;
    }

    if (nextResultCount && currentResultCount) {
      currentResultCount.textContent = nextResultCount.textContent;
    }

    if (nextSectionTitle && currentSectionTitle) {
      currentSectionTitle.textContent = nextSectionTitle.textContent;
    }

    if (currentClearButton && !nextClearButton) {
      currentClearButton.remove();
    } else if (!currentClearButton && nextClearButton) {
      document.getElementById('filter-form').append(nextClearButton);
    }

    if (updateHistory) {
      history.pushState({}, '', url);
    }

    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  } catch (error) {
    console.error(error);
    location.href = url;
  } finally {
    channelList.removeAttribute('aria-busy');
  }
}

document.addEventListener('click', (event) => {
  const link = event.target.closest('#pagination-container a.page-link,#filter-form a.clear');

  if (!link) {
    return;
  }

  event.preventDefault();
  loadPage(link.href);
});

function playStream(url, name, id, program, streamUrls = [], isJioSource = false, scroll = true) {
  const cleanedName = String(name || '')
    .replace(/\s*\((\d{3,4}[pi])\)(?:\s*\[[^\]]+\])*\s*$/i, '')
    .trim();

  const candidates = Array.isArray(streamUrls) && streamUrls.length
    ? streamUrls
    : [url].filter(Boolean);

  titleEl.textContent = cleanedName;
  titleEl.title = cleanedName;

  statusEl.textContent = 'Connecting...';
  statusEl.className = 'text-info';

  updateProgram(program, isJioSource);

  sessionStorage.setItem('iptv-current-stream', JSON.stringify({
    url: candidates[0] || url,
    name: cleanedName,
    id,
    program,
    streamUrls: candidates,
    isJioSource
  }));

  if (scroll) {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }

  loadStream(candidates[0] || url, candidates);
}

document.getElementById('filter-form').addEventListener('submit', (event) => {
  event.preventDefault();

  const url = new URL(location.href);
  url.search = new URLSearchParams(new FormData(event.target));
  url.searchParams.set('page', '1');

  loadPage(url.toString());
});

window.addEventListener('popstate', () => {
  loadPage(location.href, false);
});

const saved = sessionStorage.getItem('iptv-current-stream');

if (saved) {
  try {
    const stream = JSON.parse(saved);

    if (stream.url && stream.name) {
      playStream(
        stream.url,
        stream.name,
        stream.id,
        stream.program || '',
        stream.streamUrls || [stream.url],
        stream.isJioSource || false,
        false
      );
    }
  } catch (error) {
    sessionStorage.removeItem('iptv-current-stream');
  }
}
`;
}

module.exports = {
  clientScript
};
